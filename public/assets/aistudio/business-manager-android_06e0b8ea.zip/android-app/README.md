# Business Manager – Android app (WebView + native contacts)

This wraps your Business Manager web app in a real Android app. The big difference:
**"Phone contacts" reads your contacts directly** (one permission tap), so you can pick
customers or suppliers from your whole phone book with search and tick boxes.
Backups, PDFs and invoice images are saved straight into your phone's **Downloads** folder.

## Build the APK (about 15 minutes, needs a computer)
1. Install **Android Studio** (free): https://developer.android.com/studio
2. Open it → **New Project** → **Empty Views Activity** → Next.
   - Name: `Business Manager`
   - Package name: `com.marvi.bohrafood`   (must be exactly this)
   - Language: **Kotlin**   - Minimum SDK: **API 29 (Android 10)**
   - Finish and wait for it to load.
3. Copy files from this folder into the new project (replace when asked):
   - `app/src/main/AndroidManifest.xml`  -> same path
   - `app/src/main/java/com/marvi/bohrafood/MainActivity.kt` -> same path
   - `app/src/main/assets/index.html`    -> create the folder `assets` under `app/src/main` first
4. Open `app/build.gradle.kts` (or `build.gradle`). Inside `dependencies { ... }` add:
   `implementation("androidx.webkit:webkit:1.11.0")`
   (in the old Groovy file write: `implementation 'androidx.webkit:webkit:1.11.0'`)
   Click **Sync Now**.
5. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**. When it finishes click **locate**.
6. Send `app-debug.apk` to your phone, tap it, allow "install unknown apps", install.

## Moving your data from the web version
In the web app: More → Settings & backup → **Download backup file**.
In the new Android app: More → Settings & backup → **Restore from a backup file** and pick that file.

## Good to know
- The Android app keeps its data on the phone (no Claude sign-in, no sync between devices).
- Internet is needed for PDF export and for importing Excel/CSV files (their helper libraries load online).
- If the package name differs, change the first line of `MainActivity.kt` to match yours.
